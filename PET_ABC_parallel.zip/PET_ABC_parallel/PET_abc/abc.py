import os

os.environ["KMP_DUPLICATE_LIB_OK"] = "True"
import math
import numpy as np
from numpy import genfromtxt
import torch
import os
import pandas as pd
# from scipy.interpolate import UnivariateSpline, CubicSpline
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
import time
from torchdiffeq import odeint
from functools import partial
# from function import inputfunction
matplotlib.use("Agg")
plt.style.use("seaborn")

torch.set_default_dtype(torch.float64)

def inputfunction(t, type):
    if type == 1:
        Ct = torch.tensor([851.1, 21.9, 20.8])
        bt = torch.tensor([-4.13, -0.12, -0.01])
    elif type == 2:
        Ct = torch.tensor([12, 1.8, 0.45])
        bt = torch.tensor([-4, -0.5, -0.008])
    else:
        print("Incorrect type for input function parameters")
        print("Default values")
        Ct = torch.tensor([851.1, 21.9, 20.8])
        bt = torch.tensor([-4.13, -0.12, -0.01])

    y = (
        torch.exp(bt[0] * t) * (Ct[0] * t - Ct[1] - Ct[2])
        + Ct[2] * torch.exp(bt[1] * t)
        + Ct[2] * torch.exp(bt[2] * t)
    )
    return y


def PETabc(
    y,
    tspan,
    inputfunction = inputfunction,
    N=10 ** 6,
    type=2,
    model="single",
    a1=0.0,
    b1=0.2,
    a2=0.3,
    b2=0.5,
    a3=0.0,
    b3=0.1,
    a4=0.0,
    b4=0.2,
    PLOT=True,
    device="cpu",
):

    '''
    This function peforms ABC inference for the compartimental models.

    Input Args:
    y vector of measured radioactivity concentrations in a voxel for each time-point. This can be in terms of observations or directly in terms of voxel time activity curve.
    tspan vector of time points of observations.
    N Number of simulations. Default to 10^5.
    inputfunction A function describing the input function. Default inputfunction().
    type The type of model in the input function.
    model The type of kinetic model: "single" performs the analysis for the single-tisse model, "two" performs the analysis for the two-tissue model. Default "single".
    a1 Minimum of the uniform prior for K1. Default to 0 .
    b1 Maximum of the uniform prior for K1. Default to 0.2 .
    a2 Minimum of the uniform prior for K2. Default to 0.3 .
    b2 Maximum of the uniform prior for K2. Default to 0.5 .
    a3 Minimum of the uniform prior for K3. Default to 0 .
    b3 Maximum of the uniform prior for K3. Default to 0.1 .
    a4 Minimum of the uniform prior for K4. Default to 0 .
    b4 Maximum of the uniform prior for K4. Default to 0.2 .
    PLOT If plots have to be produced. Default at TRUE.

    return
    ABCout a matrix with values simulated from the posterior distribution of the parameters of the selected model.
    Smat a matrix with values of summary statistics of the simulated curves.
    ABCout_accepted a matrix with values simulated from the posterior distribution of the parameters of the selected model; it shows only the values accepted according to the automatically selected threshold.
    error vector of computed squared differences among the observed and the simulated summary statistics.

    '''




    Sobs = y  # check whether need to be smoothing
    if model == "single":
        parMat1 = torch.tensor([], device=device)
        error1 = torch.tensor([], device=device)
        Smat1 = torch.tensor([], device=device)

        def singtissue(t, y, K1, K2, type):
            K1c = K1
            K2c = K2
            type = type
            ipt = inputfunction(
                t, type
            )  # differential equation describing the concentration in the reference tissue input function taken from...
            dydt = K1c * ipt - K2c * y
            return dydt

    elif model == "two":
        parMat2 = torch.tensor([], device=device)
        error2 = torch.tensor([], device=device)
        Smat2 = torch.tensor([], device=device)

        def twotissue(t, y, K1, K2, K3, K4, type):
            k1 = K1
            k2 = K2
            k3 = K3
            k4 = K4
            type = type
            ipt = inputfunction(t, type)
            dydt_1 = (k1 * ipt) - (k2 * y[0]) - (k3 * y[0] + (k4 * y[1]))
            dydt_2 = k3 * y[0] - k4 * y[1]
            return torch.stack([dydt_1, dydt_2])

    sample_n = 100000
    ITER = N // sample_n
    for iter in range(ITER):
        K1 = torch.empty(sample_n, 1).uniform_(a1, b1).to(device)
        K2 = torch.empty(sample_n, 1).uniform_(a2, b2).to(device)
        if model == "single":
            odefunction = partial(singtissue, K1=K1, K2=K2, type=type)
            y_0 = torch.zeros(sample_n, 1, dtype=torch.float32)
            out = odeint(odefunction, y_0, tspan).squeeze()
            data1 = out.T
            # data1 = smooth.spline(out)
            Smat1 = torch.cat([Smat1, data1])
            error_ = ((y - data1) ** 2).sum(dim = 1)
            error1 = torch.cat([error1, error_])
            paraM1_ = torch.cat((K1, K2), dim=1)
            parMat1 = torch.cat((parMat1, paraM1_))
        elif model == "two":
            K3 = torch.empty(sample_n, 1).uniform_(a3, b3).to(device)
            K4 = torch.empty(sample_n, 1).uniform_(a3, b3).to(device)
            odefunction = partial(twotissue, K1=K1, K2=K2, K3=K3, K4=K4, type=type)
            y_0 = torch.zeros(2, sample_n, 1, dtype=torch.float32)
            out = odeint(odefunction, y_0, tspan).squeeze()
            data2 = out[:, 0].T + out[:, 1].T
            Smat2 = torch.cat([Smat2, data2])
            error_ = ((y - data2) ** 2).sum(dim=1)
            error2 = torch.cat([error2, error_])
            paraM2_ = torch.cat((K1, K2, K3, K4), dim=1)
            parMat2 = torch.cat((parMat2, paraM2_))

    if model == "single":
        h1 = torch.quantile(error1, q=0.05)
        out1 = parMat1[error1 < h1]
    else:
        h2 = torch.quantile(error2, q=0.05)
        out2 = parMat2[error2 < h2]

    if PLOT:
        if model == 'single':
            f, ax = plt.subplots(1, 2, figsize=(5, 5))
            sns.kdeplot(out1[:, 0], ax=ax[0])
            ax[0].axvline(x=out1[:, 0].mean(), linestyle="--")
            ax[0].set_xlabel("$K_{1}$")   

            sns.kdeplot(out1[:, 1], ax=ax[1])
            ax[1].axvline(x=out1[:, 1].mean(), linestyle="--")
            ax[1].set_xlabel("$K_{2}$")       
            plt.savefig("figure/posterior_singletissue.png", dpi=200, bbox_inches="tight")      

        elif model == 'two':
            f, ax = plt.subplots(2, 2, figsize=(5, 5))
            sns.kdeplot(out2[:, 0], ax=ax[0,0])
            ax[0,0].axvline(x=out2[:, 0].mean(), linestyle="--")
            ax[0,0].set_xlabel("$K_{1}$")   

            sns.kdeplot(out2[:, 1], ax=ax[0,1])
            ax[0,1].axvline(x=out2[:, 1].mean(), linestyle="--")
            ax[0,1].set_xlabel("$K_{2}$")    

            sns.kdeplot(out2[:, 2], ax=ax[1,0])
            ax[1,0].axvline(x=out2[:, 2].mean(), linestyle="--")
            ax[1,0].set_xlabel("$K_{3}$")   

            sns.kdeplot(out2[:, 3], ax=ax[1,1])
            ax[1,1].axvline(x=out2[:, 3].mean(), linestyle="--")
            ax[1,1].set_xlabel("$K_{4}$")    

            plt.savefig("figure/posterior_twotissue.png", dpi=200, bbox_inches="tight")                       

    if model == "single":
        torch.save(
            {"para": parMat1, "Smat": Smat1, "error1": error1, "accept": out1},
            "single_model_output.pt",
        )
        return {"para": parMat1, "Smat": Smat1, "error1": error1, "accept": out1}

    elif model == "two":
        torch.save(
            {"para": parMat2, "Smat": Smat2, "error1": error2, "accept": out2},
            "two_tissue_model_output.pt",
        )
        return {"para": parMat2, "Smat": Smat2, "error1": error2, "accept": out2}



if __name__ == '__main__':
    #single tissue
    my_data = genfromtxt('Data-Pois-12C-l1.csv', delimiter='')
    data = torch.from_numpy(my_data[:,0])#choose one data
    t = torch.arange(0,61).to(torch.float32)
    result = PETabc(data,tspan=t,PLOT=True)

    #two tissue model

    my_data = genfromtxt('Data-Pois-22C-l1.csv', delimiter='')
    
    data = torch.from_numpy(my_data[:,0])
    t = torch.arange(0,61).to(torch.float32)
    result = PETabc(data,tspan=t,model = 'two')    
    pass
