import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "True"
import math
import numpy as np
import torch
import os
import pandas as pd
from scipy.interpolate import UnivariateSpline, CubicSpline
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
from functools import partial
import time
from torchdiffeq import odeint
from math import log10
from torch.distributions.poisson import Poisson

matplotlib.use("Agg")
plt.style.use("seaborn")

torch.set_default_dtype(torch.float32)


def inputfunction(t, type):
    if type == 1:
        Ct = torch.tensor([851.1, 21.9, 20.8])
        bt = torch.tensor([-4.13, -0.12, -0.01])
    elif type == 2:
        Ct = torch.tensor([12, 1.8, 0.45])
        bt = torch.tensor([-4, -0.5, -0.008])
    else:
        print("Incorrect type for input function parameters")
        print("Default values")
        Ct = torch.tensor([851.1, 21.9, 20.8])
        bt = torch.tensor([-4.13, -0.12, -0.01])

    y = (
        torch.exp(bt[0] * t) * (Ct[0] * t - Ct[1] - Ct[2])
        + Ct[2] * torch.exp(bt[1] * t)
        + Ct[2] * torch.exp(bt[2] * t)
    )
    return y


def singtissue(t, y, K1, K2, type=2, inputfunction=inputfunction):
    K1c = K1
    K2c = K2
    type = type
    ipt = inputfunction(
        t, type
    )  # differential equation describing the concentration in the reference tissue input function taken from...
    dydt = K1c * ipt - K2c * y[:0]
    return dydt


def twotissue(t, y, K1, K2, K3, K4, type):
    k1 = K1
    k2 = K2
    k3 = K3
    k4 = K4
    type = type
    ipt = inputfunction(t, type)
    dydt_1 = (k1 * ipt) - (k2 * y[:, 0]) - (k3 * y[:, 0] + (k4 * y[:, 1]))
    dydt_2 = k3 * y[:, 0] - k4 * y[:, 1]
    return torch.stack([dydt_1, dydt_2])


def TAC_One_Compartment(
    K1=0.0918,
    K2=0.4484,
    noise="Pois",
    PLOT=False,
    l2=1,
    l1=3,
    tspan=torch.arange(1, 61),
    inputfunction=inputfunction,
    type=2,
):
    tspan = tspan.to(torch.float32)
    Ct0 = torch.tensor(0,dtype=torch.float32)

    def singtissue(t, y, K1, K2, type):
        K1c = K1
        K2c = K2
        type = type
        ipt = inputfunction(
            t, type
        )  # differential equation describing the concentration in the reference tissue input function taken from...
        dydt = K1c * ipt - K2c * y
        return dydt

    K1 = torch.tensor(K1)
    K2 = torch.tensor(K2)
    odefunction = partial(singtissue, K1=K1, K2=K2, type=type)
    out = odeint(odefunction, Ct0, tspan).squeeze()
    Ct = out.T

    if noise == "norm":
        nmin = 0.001
        nmax = 0.1
        n = 10 ** (torch.linspace(log10(nmin), log10(nmax), 10))

        noiselevel = n[l1]  # choosinglevel of noise for normally distributed noise
        x = torch.randn(Ct.shape)
        ynoise = Ct + noiselevel * x
        if PLOT:
            plt.plot(tspan, ynoise)
            plt.xlabel("time")
            plt.ylabel("Concentration of the radiotracer")
            plt.plot(tspan, Ct)
            plt.title("TAC Target tissue")
        return ynoise

    elif noise == "Pois":
        l1 = Ct.shape[0]
        count = 10 ** (torch.linspace(3, 6, 20))
        calib = count[l2] / Ct.sum()  # choosing level of noise
        m = Poisson(calib * Ct)
        ynoise1 = m.sample() / calib  # adding poisson noise

        return ynoise1

    elif noise == "mixed":
        ll = Ct.shape[0]
        poissonN = 10 ** (torch.linspace(3, 6, 20))
        calib = poissonN[l2] / Ct.sum()  # choosing level of noise
        m = Poisson(calib * Ct, dtype=torch.float32)
        ynoise1 = m.sample() / calib  # adding poisson noise

        nmin = 0.001
        nmax = 0.1
        n = 10 ** (torch.linspace(log10(nmin), log10(nmax), 10))

        noiselevel = n[l1]  # choosinglevel of noise for normally distributed noise
        x = torch.randn(Ct.shape)
        ynoise = Ct + noiselevel * x

        return {"ynoise1": ynoise1, "ynoise2": ynoise}


def TAC_2_Compartment(K1=0.0918,
    K2=0.4484,
    K3 = 0.0482,
    K4 = 0.1363,
    noise="Pois",
    PLOT=False,
    l2=1,
    l1=3,
    tspan=torch.arange(0, 61),
    inputfunction=inputfunction,
    type=2):

    tspan = tspan.to(torch.float32)
    def twotissue(t, y, K1, K2, K3, K4, type):
        k1 = K1
        k2 = K2
        k3 = K3
        k4 = K4
        type = type
        ipt = inputfunction(t, type)
        dydt_1 = (k1 * ipt) - (k2 * y[0]) - (k3 * y[0] + (k4 * y[1]))
        dydt_2 = k3 * y[0] - k4 * y[1]
        return torch.stack([dydt_1, dydt_2])
    
    y_0 = torch.zeros(2)
    odefunction = partial(twotissue, K1=K1, K2=K2, K3 = K3,K4 = K4,type=type)
    out = odeint(odefunction, y_0, tspan).squeeze()
    Ct = out[:, 0].T + out[:, 1].T
    if noise == "norm":
        nmin = 0.001
        nmax = 0.1
        n = 10 ** (torch.linspace(log10(nmin), log10(nmax), 10))

        noiselevel = n[l1]  # choosinglevel of noise for normally distributed noise
        x = torch.randn(Ct.shape)
        ynoise = Ct + noiselevel * x
        if PLOT:
            plt.plot(tspan, ynoise)
            plt.xlabel("time")
            plt.ylabel("Concentration of the radiotracer")
            plt.plot(tspan, Ct)
            plt.title("TAC Target tissue")
        return ynoise

    elif noise == "Pois":
        l1 = Ct.shape[0]
        count = 10 ** (torch.linspace(3, 6, 20))
        calib = count[l2] / Ct.sum()  # choosing level of noise
        m = Poisson(calib * Ct)
        ynoise1 = m.sample() / calib  # adding poisson noise

        return ynoise1

    elif noise == "mixed":
        ll = Ct.shape[0]
        poissonN = 10 ** (torch.linspace(3, 6, 20))
        calib = poissonN[l2] / Ct.sum()  # choosing level of noise
        m = Poisson(calib * Ct)
        ynoise1 = m.sample() / calib  # adding poisson noise

        nmin = 0.001
        nmax = 0.1
        n = 10 ** (torch.linspace(log10(nmin), log10(nmax), 10))

        noiselevel = n[l1]  # choosinglevel of noise for normally distributed noise
        x = torch.randn(Ct.shape)
        ynoise = Ct + noiselevel * x

        return {"ynoise1": ynoise1, "ynoise2": ynoise}


def Crsolve(t):

    Ct = torch.tensor([12,1.8,0.45])
    bt = torch.tensor([-4,-0.5,-0.008])
    y = (
        torch.exp(bt[0] * t) * (Ct[0] * t - Ct[1] - Ct[2])
        + Ct[2] * torch.exp(bt[1] * t)
        + Ct[2] * torch.exp(bt[2] * t)
    )
    return y

def oneTissueTAC(tspan,K1,K2):
    Cthat = torch.tensor([])
    for i in range(tspan.shape[0]):
        tt = tspan[i]
        tau = torch.linspace(0,tt,200)
        difftau = torch.diff(tau)
        Cthat = torch.cat([Cthat,difftau])
    return Cthat




if __name__ == '__main__':
    sample_1_tissue = TAC_One_Compartment()
    sample_2_tissue = TAC_2_Compartment()
    print('Finished')