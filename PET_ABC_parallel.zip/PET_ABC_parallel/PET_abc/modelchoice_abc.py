import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "True" #for macos 
import math
import numpy as np
import torch
import os
import pandas as pd
# from scipy.interpolate import UnivariateSpline, CubicSpline
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
import time
# from function import inputfunction

matplotlib.use("Agg")
plt.style.use("seaborn")

torch.set_default_dtype(torch.float64)


def inputfunction(t, type):
    if type == 1:
        Ct = torch.tensor([851.1, 21.9, 20.8])
        bt = torch.tensor([-4.13, -0.12, -0.01])
    elif type == 2:
        Ct = torch.tensor([12, 1.8, 0.45])
        bt = torch.tensor([-4, -0.5, -0.008])
    else:
        print("Incorrect type for input function parameters")
        print("Default values")
        Ct = torch.tensor([851.1, 21.9, 20.8])
        bt = torch.tensor([-4.13, -0.12, -0.01])

    y = (
        torch.exp(bt[0] * t) * (Ct[0] * t - Ct[1] - Ct[2])
        + Ct[2] * torch.exp(bt[1] * t)
        + Ct[2] * torch.exp(bt[2] * t)
    )
    return y


def MC_abc(y,tspan,abc_single,abc_two,tol1=False,tol2=False,inputfunction=inputfunction,type=2,PLOT=False):
    '''
    This function peforms model choice between the single-tissue and the
    two-tissue models based on the outputs of the PETabc() function.

    Input Args:
    y vector of measured radioactivity concentrations in a voxel for
    each time-point. This can be in terms of observations or directly in terms
    of voxel time activity curve.
    tspan vector of time points of observations.
    abc_single output of the PETabc() function for the single-tissue
    single-tissue compartment model
    abc_two output of the PETabc() function for the two-tissue
    single-tissue compartment model
    tol1 tolerance level for the single-tissue model. The tolerance is given in terms
    of percentage of posterior values to keep.
    If tol1=False, the tolerance level automatically chosen by the PETabc()
    function will be used. Default False.
    tol2 tolerance level for the two-tissue model. The tolerance is given in terms
    of percentage of posterior values to keep.
    If tol2=False, the tolerance level automatically chosen by the PETabc()
    function will be used. Default False.
    inputfunction A function describing the input function.
    Default inputfunction().
    type The type of model in the input function.
    PLOT If plots have to be produced. Default at FALSE.

    return
    FalsepostProb posterior probabilities of the single-tissue compartment model.
    FalseRMSEsingle root mean squared error of the single-tissue compartment model (on a grid of tolerance levels).
    FalseRMSEtwo root mean squared error of the two-tissue compartment model (on a grid of tolerance levels).    
    '''
    error1 = abc_single['error1']
    error2 = abc_two['error1']

    parMat1 = abc_single['para']
    parMat2 = abc_two['para']

    if tol1 is False:
        parM1 = abc_single['accept'].mean(dim = 0)
    else:
        h1 = torch.quantile(error1,probs=tol1)
        out1 = parMat1[error1<h1]
        parM1 = out1.mean(dim = 0)
    
    if tol2 is False:
        parM2 = abc_two['accept'].mean(dim = 0)
    else:
        h2 = torch.quantile(error2,probs=tol2)
        out2 = parMat2[error2<h2]
        parM2 = out2.mean(dim = 0)    

    lprob_grid = torch.linspace(math.log(0.001),math.log(0.05),20)
    hgrid1=torch.quantile(error1,q=torch.exp(lprob_grid))
    # hgrid2=torch.quantile(error2,q=torch.exp(lprob_grid))
    RMSE1 = torch.zeros_like(lprob_grid)
    RMSE2 = torch.zeros_like(lprob_grid)
    mprob1 = torch.zeros_like(lprob_grid)
    mprob2 = torch.zeros_like(lprob_grid)    
    for index in range(RMSE1.shape[0]):
        ind=error1<hgrid1[index]
        RMSE1[index]=torch.sqrt(((parMat1[ind].mean(dim=0)-parM1)**2).mean())
        mprob1[index] = ind.sum()
    for index in range(RMSE2.shape[0]):
        ind=error2<hgrid1[index]
        RMSE2[index]=torch.sqrt(((parMat2[ind].mean(dim=0)-parM2)**2).mean())
        mprob2[index] = ind.sum()
    prob = mprob1/(mprob1+mprob2)


    if PLOT is True:

        fig, ax = plt.subplots(1)
        ax.plot(lprob_grid.exp().numpy(),prob.numpy())
        indgrid1 = RMSE1.min(dim=0)[1] #take the indice
        indgrid2 = RMSE2.min(dim=0)[1] #take the indice
        hh = (lprob_grid.exp()[indgrid1]+lprob_grid.exp()[indgrid2])/2
        ax.axvline(x=hh, linestyle="-")
        ax.set_xlabel('tolerance')
        ax.set_ylabel('model prob')
        plt.savefig("figure/modelprobWW_M1.png", dpi=200, bbox_inches="tight")
        plt.close()


        fig, ax = plt.subplots(1)
        ax.plot(lprob_grid.exp().numpy(),RMSE1.numpy())
        indgrid1 = RMSE1.min(dim=0)[1] #take the indice
        ax.plot(lprob_grid.exp().numpy(),RMSE2.numpy(),linestyle='--')
        indgrid2 = RMSE2.min(dim=0)[1] #take the indice
        hh = (lprob_grid.exp()[indgrid1]+lprob_grid.exp()[indgrid2])/2
        ax.axvline(x=hh, linestyle="-")
        ax.set_xlabel('tolerance')
        ax.set_ylabel('RMSE')
        plt.savefig("figure/modelprobWW_RMSE.png", dpi=200, bbox_inches="tight")
        plt.close()



    return {'postprob':prob,'RMSEsingle' :RMSE1,'RMSEtwo' : RMSE2}