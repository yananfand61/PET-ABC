import os

os.environ["KMP_DUPLICATE_LIB_OK"] = "True"  # for macos
import math
import numpy as np
import torch
import os
import pandas as pd
# from scipy.interpolate import UnivariateSpline, CubicSpline
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
import time


matplotlib.use("Agg")
plt.style.use("seaborn")

torch.set_default_dtype(torch.float64)


def Gen_Curve(Ct, Cr, Ti, R1, K2, K2a, gamma, tD, tP, alpha):
    """
     Generate data from lp-ntPET model
     This function generate the data from the lp-ntPET model as in Normandin (2012).
     Input Args:
     Ct vector of concentration values of the tracer in the target tissue.
     Cr vector of concentration values in the reference regions.
     Ti vector of time points of observations.
     R1 value of the R1 parameter.
     K2 value of the K2 parameter.
     K2a value of the K2a parameter.
     gamma value of the activation parameter.
     tD delay time at which the response starts.
     tP peak time of maximal response.
     alpha sharpeness parameters of the response function.

    output:
    M1 data under the model with no activation (gamma=0).
    M2 data under the model with activation (gamma different from 0).
    """

    try:
        n_sample = R1.shape[0]
        if n_sample == 1:
            R1 = R1.unsqueeze(dim=0)
            K2 = K2.unsqueeze(dim=0)
            K2a = K2a.unsqueeze(dim=0)
            tD = tD.unsqueeze(dim=0)
            tP = tP.unsqueeze(dim=0)
            alpha = alpha.unsqueeze(dim=0)
            gamma = gamma.view(1, 1)
    except IndexError:
        n_sample = 1
        R1 = R1.unsqueeze(dim=0).unsqueeze(dim=0)
        K2 = K2.unsqueeze(dim=0).unsqueeze(dim=0)
        K2a = K2a.unsqueeze(dim=0).unsqueeze(dim=0)
        tD = tD.unsqueeze(dim=0).unsqueeze(dim=0)
        tP = tP.unsqueeze(dim=0).unsqueeze(dim=0)
        alpha = alpha.unsqueeze(dim=0).unsqueeze(dim=0)
        gamma = gamma.unsqueeze(dim=0).unsqueeze(dim=0)
    col1 = Cr.unsqueeze(0).repeat(n_sample, 1)
    col2 = torch.cumsum(Cr.unsqueeze(0).repeat(n_sample, 1), dim=1)
    col3 = -torch.cumsum(Ct.unsqueeze(0).repeat(n_sample, 1), dim=1)
    Ind = (Ti - tD) > 0
    ht_ = torch.exp(alpha * (1 - (Ti - tD) / (tP - tD)))
    ht_[~Ind] = 0
    ht = torch.max(torch.tensor(0), (Ti - tD) / (tP - tD)) ** (alpha) * ht_
    col4 = -torch.cumsum(Ct * ht, dim=1)
    BigMat = torch.stack([col1, col2, col3, col4], dim=2)
    theta = torch.cat([R1, K2, K2a, gamma], dim=1).unsqueeze(2)
    M2 = torch.bmm(BigMat.to(theta.dtype), theta).squeeze()
    theta0 = torch.cat([R1, K2, K2a, torch.zeros_like(K2a)], dim=1).unsqueeze(2)
    M1 = torch.bmm(BigMat.to(theta.dtype), theta0).squeeze()
    return M1, M2


def smooth_spline(t, x, smooth_factor=150):  # slow function, need to be modified
    """
    t is the distinct values in increasing order
    x the fitted values corresponding to t
    """
    if x.dim() == 1:
        x = x.view(1, -1)
    elif x.dim() >= 3:
        raise ValueError

    device = t.device
    if device != "cpu":
        t = t.to("cpu")
        x = x.to("cpu")

    out = torch.zeros_like(x)
    for p in range(x.shape[0]):
        spl = UnivariateSpline(t.numpy(), x[p].numpy(), k=3)
        spl.set_smoothing_factor(smooth_factor)
        out[p] = torch.from_numpy(spl(t))

    return out.to(device)


def MC_abc_lpntPET(Ct, Cr, Ti, abc_out, tol1=False, tol2=False, PLOT=False):
    """
    This function peforms model choice between the lp-ntPET model with activation and without activation.

    Input Args:
    Ct vector of concentration values of the tracer in the target tissue.
    Cr vector of concentration values in the reference regions.
    Ti vector of time points of observations.
    abc_out output of the lp_ntPETabc() function for the lp-ntPET model (both with and without activation).
    tol1 tolerance level for the lp-ntPET model with no activation. The tolerance is given in terms of percentage of posterior values to keep.
    If tol1=False, the tolerance level automatically chosen by the lp_ntPETabc() function will be used. Default False.
    tol2 tolerance level for the lp-ntPET model with activation. The tolerance is given in terms of percentage of posterior values to keep.
    If tol2=False, the tolerance level automatically chosen by the lp_ntPETabc() function will be used. Default False.

    return:

    postProb posterior probabilities of the lp-ntPET model with no activation.
    RMSEnoact root mean squared error of the lp-ntPET model with no activation (on a grid of tolerance levels).
    RMSEact root mean squared error of the lp-ntPET model with activation (on a grid of tolerance levels).
    PLOT If plots have to be produced. Default at FALSE.

    """

    parM1_nnls = abc_out["obj_nnls_noa"]
    parM2_nnls = abc_out["nnls_a"]

    error1 = abc_out["error_noact"]
    error2 = abc_out["error_act"]

    parMat1 = abc_out["ABCout_noact"]
    parMat2 = abc_out["ABCout_act"]

    if tol1:
        h1 = torch.quantile(error1, probs=tol1)
        out1 = parMat1[error1 < h1]
        parM1_mean = out1.mean(dim=0)
        parM1_mode = out1.mode(dim=0)[0]
        parM1_median = out1.median(dim=0)[0]
    else:
        parM1_mean = abc_out["ABCout_noact_accepted"].mean(dim=0)
        parM1_mode = abc_out["ABCout_noact_accepted"].mode(dim=0)[0]
        parM1_median = abc_out["ABCout_noact_accepted"].median(dim=0)[0]

    if tol2:
        h2 = torch.quantile(error2, probs=tol2)
        out2 = parMat2[error2 < h2]
        parM2_mean = out2.mean(dim=0)
        parM2_mode = out2.mode(dim=0)[0]
        parM2_median = out2.median(dim=0)[0]
    else:
        parM2_mean = abc_out["ABCout_act_accepted"].mean(dim=0)
        parM2_mode = abc_out["ABCout_act_accepted"].mode(dim=0)[0]
        parM2_median = abc_out["ABCout_act_accepted"].median(dim=0)[0]

    lprob_grid = torch.linspace(math.log(0.00001), math.log(0.05), 20)
    hgrid1 = torch.quantile(error1, q=torch.exp(lprob_grid))
    hgrid2 = torch.quantile(error2, q=torch.exp(lprob_grid))
    RMSE1 = torch.zeros_like(lprob_grid)
    RMSE2 = torch.zeros_like(lprob_grid)
    mprob1 = torch.zeros_like(lprob_grid)
    mprob2 = torch.zeros_like(lprob_grid)
    for index in range(RMSE1.shape[0]):
        ind = error1 < hgrid1[index]
        RMSE1[index] = torch.sqrt(((parMat1[ind].mean(dim=0) - parM1_mean) ** 2).mean())
        mprob1[index] = (error1 < torch.min(hgrid1[index], hgrid2[index])).sum()
    for index in range(RMSE2.shape[0]):
        ind = error1 < hgrid2[index]
        RMSE2[index] = torch.sqrt(((parMat2[ind].mean(dim=0) - parM2_mean) ** 2).mean())
        mprob2[index] = (error2 < torch.min(hgrid1[index], hgrid2[index])).sum()

    prob = mprob1 / (mprob1 + mprob2)

    if PLOT is True:
        data1sim_mean = Gen_Curve(
            Ct,
            Cr,
            Ti,
            R1=parM1_mean[0],
            K2=parM1_mean[1],
            K2a=parM1_mean[2],
            gamma=torch.tensor(0),
            tD=parM2_mean[4],
            tP=parM2_mean[5],
            alpha=parM2_mean[6],
        )[0]
        data2sim_mean = Gen_Curve(
            Ct,
            Cr,
            Ti,
            R1=parM2_mean[0],
            K2=parM2_mean[1],
            K2a=parM2_mean[2],
            gamma=parM2_mean[3],
            tD=parM2_mean[4],
            tP=parM2_mean[5],
            alpha=parM2_mean[6],
        )[1]

        data1sim_mode = Gen_Curve(
            Ct,
            Cr,
            Ti,
            R1=parM1_mode[0],
            K2=parM1_mode[1],
            K2a=parM1_mode[2],
            gamma=torch.tensor(0),
            tD=parM2_mode[4],
            tP=parM2_mode[5],
            alpha=parM2_mode[6],
        )[0]
        data2sim_mode = Gen_Curve(
            Ct,
            Cr,
            Ti,
            R1=parM2_mode[0],
            K2=parM2_mode[1],
            K2a=parM2_mode[2],
            gamma=parM2_mode[3],
            tD=parM2_mode[4],
            tP=parM2_mode[5],
            alpha=parM2_mode[6],
        )[1]

        data1sim_median = Gen_Curve(
            Ct,
            Cr,
            Ti,
            R1=parM1_median[0],
            K2=parM1_median[1],
            K2a=parM1_median[2],
            gamma=torch.tensor(0),
            tD=parM2_median[3],
            tP=parM2_median[4],
            alpha=parM2_median[5],
        )[0]
        data2sim_median = Gen_Curve(
            Ct,
            Cr,
            Ti,
            R1=parM2_median[0],
            K2=parM2_median[1],
            K2a=parM2_median[2],
            gamma=parM2_median[3],
            tD=parM2_median[4],
            tP=parM2_median[5],
            alpha=parM2_median[6],
        )[1]

        data1sim_nnls = Gen_Curve(
            Ct,
            Cr,
            Ti,
            R1=parM1_nnls[0],
            K2=parM1_nnls[1],
            K2a=parM1_nnls[2],
            gamma=torch.tensor(0),
            tD=parM2_nnls[4],
            tP=parM2_nnls[5],
            alpha=parM2_nnls[6],
        )[0]
        data2sim_nnls = Gen_Curve(
            Ct,
            Cr,
            Ti,
            R1=parM2_nnls[0],
            K2=parM2_nnls[1],
            K2a=parM2_nnls[2],
            gamma=parM2_nnls[3],
            tD=parM2_nnls[4],
            tP=parM2_nnls[5],
            alpha=parM2_nnls[6],
        )[1]

        fig, ax = plt.subplots(1)
        ax.plot(Ti, Ct, label="True data")

        ax.plot(Ti, data1sim_mean, "-", label="no activ mean")
        ax.plot(Ti, data2sim_mean, label="activ mean")

        ax.plot(Ti, data1sim_median, label="no activ median")
        ax.plot(Ti, data2sim_median, label="activ median")

        ax.plot(Ti, data1sim_nnls, label="no activ nnls")
        ax.plot(Ti, data2sim_nnls, label="activ nnls")

        ax.legend()
        plt.savefig("figure/modelprob_TAC.png", dpi=200, bbox_inches="tight")
        plt.close()

        fig, ax = plt.subplots(1)
        ax.plot(lprob_grid.exp().numpy(),prob.numpy())
        indgrid1 = RMSE1.min(dim=0)[1] #take the indice
        indgrid2 = RMSE2.min(dim=0)[1] #take the indice
        hh = (lprob_grid.exp()[indgrid1]+lprob_grid.exp()[indgrid2])/2
        ax.axvline(x=hh, linestyle="-")
        ax.set_xlabel('tolerance')
        ax.set_ylabel('model prob')
        plt.savefig("figure/modelprobWW_M1.png", dpi=200, bbox_inches="tight")
        plt.close()


        fig, ax = plt.subplots(1)
        ax.plot(lprob_grid.exp().numpy(),RMSE1.numpy())
        indgrid1 = RMSE1.min(dim=0)[1] #take the indice
        ax.plot(lprob_grid.exp().numpy(),RMSE2.numpy(),linestyle='--')
        indgrid2 = RMSE2.min(dim=0)[1] #take the indice
        hh = (lprob_grid.exp()[indgrid1]+lprob_grid.exp()[indgrid2])/2
        ax.axvline(x=hh, linestyle="-")
        ax.set_xlabel('tolerance')
        ax.set_ylabel('RMSE')
        plt.savefig("figure/modelprobWW_RMSE.png", dpi=200, bbox_inches="tight")
        plt.close()


        fig, ax = plt.subplots(2)
        ax[0].plot(lprob_grid.exp().numpy(),RMSE1.numpy())
        indgrid1 = RMSE1.min(dim=0)[1] #take the indice
        hh = lprob_grid.exp()[indgrid1]
        ax[0].axvline(x=hh, linestyle="-")
        ax[0].set_xlabel('tolerance')
        ax[0].set_ylabel('RMSE')
        ax[0].set_title('no act')

        ax[1].plot(lprob_grid.exp().numpy(),RMSE2.numpy(),linestyle='--')
        indgrid2 = RMSE2.min(dim=0)[1] #take the indice
        hh = (lprob_grid.exp()[indgrid1]+lprob_grid.exp()[indgrid2])/2
        ax[1].axvline(x=hh, linestyle="-")
        ax[1].set_xlabel('tolerance')
        ax[1].set_ylabel('RMSE')
        ax[1].set_title('act')
        plt.savefig("figure/modelprobWW_RMSE_two.png", dpi=200, bbox_inches="tight")
        plt.close()



    hdf1 = {str(round(lprob_grid.exp()[i].item(),5)):hgrid1[i].item() for i in range(hgrid1.shape[0])}
    hdf2 = {str(round(lprob_grid.exp()[i].item(),5)):hgrid2[i].item() for i in range(hgrid2.shape[0])}

    return {'postProb':prob,'RMSEnoact':RMSE1,'err_noact':hdf1,'err_act':hdf2,'paraMnoact':parM1_mean,'parMact_mean':parM2_mean,'parMnoact_mode':parM1_mode,'parMact_mode':parM2_mode,'parMnoact_med':parM1_median,'parMact_med':parM2_median}



