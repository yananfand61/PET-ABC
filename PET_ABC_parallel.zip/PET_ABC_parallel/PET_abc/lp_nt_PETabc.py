import os

os.environ["KMP_DUPLICATE_LIB_OK"] = "True"
import math
import numpy as np
import torch
import os
import pandas as pd
from scipy.interpolate import UnivariateSpline, CubicSpline
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
import time


matplotlib.use("Agg")
plt.style.use("seaborn")

torch.set_default_dtype(torch.float64)


def Gen_Curve(Ct, Cr, Ti, R1, K2, K2a, gamma, tD, tP, alpha):
    """
     Generate data from lp-ntPET model
     This function generate the data from the lp-ntPET model as in Normandin (2012).
     Input Args:
     Ct vector of concentration values of the tracer in the target tissue.
     Cr vector of concentration values in the reference regions.
     Ti vector of time points of observations.
     R1 value of the R1 parameter.
     K2 value of the K2 parameter.
     K2a value of the K2a parameter.
     gamma value of the activation parameter.
     tD delay time at which the response starts.
     tP peak time of maximal response.
     alpha sharpeness parameters of the response function.

    output:
    M1 data under the model with no activation (gamma=0).
    M2 data under the model with activation (gamma different from 0).
    """

    try:
        n_sample = R1.shape[0]
        if n_sample == 1:
            R1 = R1.unsqueeze(dim=0)
            K2 = K2.unsqueeze(dim=0)
            K2a = K2a.unsqueeze(dim=0)
            tD = tD.unsqueeze(dim=0)
            tP = tP.unsqueeze(dim=0)
            alpha = alpha.unsqueeze(dim=0)
            gamma = gamma.view(1, 1)
    except IndexError:
        n_sample = 1
        R1 = R1.unsqueeze(dim=0).unsqueeze(dim=0)
        K2 = K2.unsqueeze(dim=0).unsqueeze(dim=0)
        K2a = K2a.unsqueeze(dim=0).unsqueeze(dim=0)
        tD = tD.unsqueeze(dim=0).unsqueeze(dim=0)
        tP = tP.unsqueeze(dim=0).unsqueeze(dim=0)
        alpha = alpha.unsqueeze(dim=0).unsqueeze(dim=0)
        gamma = gamma.unsqueeze(dim=0).unsqueeze(dim=0)
    col1 = Cr.unsqueeze(0).repeat(n_sample, 1)
    col2 = torch.cumsum(Cr.unsqueeze(0).repeat(n_sample, 1), dim=1)
    col3 = -torch.cumsum(Ct.unsqueeze(0).repeat(n_sample, 1), dim=1)
    ht = compute_ht(Ti, tD, tP, alpha)
    col4 = -torch.cumsum(Ct * ht, dim=1)
    BigMat = torch.stack([col1, col2, col3, col4], dim=2)
    theta = torch.cat([R1, K2, K2a, gamma], dim=1).unsqueeze(2)
    M2 = torch.bmm(BigMat.to(theta.dtype), theta).squeeze()
    theta0 = torch.cat([R1, K2, K2a, torch.zeros_like(K2a)], dim=1).unsqueeze(2)
    M1 = torch.bmm(BigMat.to(theta.dtype), theta0).squeeze()
    return M1, M2


def smooth_spline(t, x, smooth_factor=150):  # slow function, need to be modified
    """
    t is the distinct values in increasing order
    x the fitted values corresponding to t
    """
    if x.dim() == 1:
        x = x.view(1, -1)
    elif x.dim() >= 3:
        raise ValueError

    device = t.device
    if device != "cpu":
        t = t.to("cpu")
        x = x.to("cpu")

    out = torch.zeros_like(x)
    for p in range(x.shape[0]):
        spl = UnivariateSpline(t.numpy(), x[p].numpy(), k=3)
        spl.set_smoothing_factor(smooth_factor)
        out[p] = torch.from_numpy(spl(t))

    return out.to(device)


def compute_ht(Ti, tD, tP, alpha):
    """
    compute function h(t) in eq 6 of PETabc paper
    The function h(t) describes the non-steady state component of the kinetic mode
    """
    Ind = (Ti - tD) > 0
    ht_ = torch.exp(alpha * (1 - (Ti - tD) / (tP - tD)))
    ht_[~Ind] = 0
    ht = torch.max(torch.tensor(0), (Ti - tD) / (tP - tD)) ** (alpha) * ht_
    return ht


def lp_nt_PETabc(
    Ct,
    Cr,
    Ti,
    R1a=0.8,
    R1b=1.1,
    K2alpha=0.2,
    K2beta=0.6,
    K2a_alpha=0.1,
    K2a_beta=0.4,
    gamma_a=0,
    gamma_b=0.2,
    tD_a=15,
    tD_b=25,
    tP_b=40,
    alpha_a=0,
    alpha_b=3,
    k2a_per=100,
    k2a_int=[0.25, 0.75],
    h=0.05,
    S=10 ** 5,
    PLOT=True,
    nnls=False,
    Sequential=False,
    Seq=0,
):
    """
    This function peforms ABC inference for the lp-nt model.
    Input Args:
    Ct vector of concentration values of the tracer in the target tissue.
    Cr vector of concentration values in the reference regions.
    Ti vector of time points of observations.
    S number of simulations. Default at 10^5.
    R1a lower bound of the uniform prior distribution for R1. Default at 0.5.
    R1a upper bound of the uniform prior distribution for R1. Default at 1.6.
    K2alpha lower bound of the uniform prior distribution for K2. Default at 0.
    K2beta upper bound of the uniform prior distribution for K2. Default at 1.
    K2a_alpha lower bound of the uniform prior distribution for K2a. Default at 0.
    K2a_beta upper bound of the uniform prior distribution for K2a. Default at 0.6.
    gamma_a lower bound of the uniform prior distribution for gamma. Default at 0.
    gamma_b upper bound of the uniform prior distribution for gamma. Default at 0.2.
    tD_a lower bound of the uniform prior distribution for tD. Default at 18.
    tD_b upper bound of the uniform prior distribution for tD. Default at 22.
    tP_b upper bound of the uniform prior distribution for tP. Default at 40.
    alpha_a lower bound of the uniform prior distribution for alpha. Default at 0.
    alpha_b upper bound of the uniform prior distribution for alpha. Default at 3.
    k2a_per baseline value for k2a (in percentage). Default value at 100.
    k2a_int levels of the credible intervals for k2a(t). Default value at (0.25,0.75).
    lsq type of least squares estimation: 1 for non-negative least squares, 2 for weighted non-negative least squares. Default at 1.
    PLOT If plots have to be produced. Default at TRUE.

    return:
    ABCout_act a tensor with values simulated from the posterior distribution of the parameters of the model with activation.
    Smat_act a tensor with values of summary statistics of the simulated curves for the model with activation.
    ABCout_act_accepted a tensor with values simulated from the posterior distribution of the parameters of the model with activation; it shows only the values accepted according to the automatically selected threshold.
    error_act vector of computed squared differences among the observed and the simulated summary statistics for the model with activation.
    tol_act automatically selected tolerance level for the model with activation; this tolerance level is used to define the tensor ABCout_accepted.
    ABCout_noact a tensor with values simulated from the posterior distribution of the parameters of the model with no activation.
    Smat_noact a tensor with values of summary statistics of the simulated curves for the model with no activation.
    ABCout_noact_accepted a tensor with values simulated from the posterior distribution of the parameters of the model with no activation; it shows only the values accepted according to the automatically selected threshold.
    error_noact vector of computed squared differences among the observed and the simulated summary statistics for the model with no activation.
    tol_noact automatically selected tolerance level for the model with no activation; this tolerance level is used to define the tensor ABCout_accepted.
    nnls_noa non-negative linear least square estimates of the parameter for the model with no activation
    nnls_a non-negative linear least square estimates of the parameter for the model with activation
    k2at_all k2a(t) function for the model with activation, tensor of S x T values (total number of simulations x number of time points)
    k2at_acc k2a(t) function for the model with activation only for the accepted values of the paramters, tensor of (tol*S) x T values (number of accepted simulations x number of time points)

    """
    col1 = Cr

    ###nnls
    if nnls:
        col2 = torch.cat(
            [torch.tensor([0], device=Cr.device), torch.cumulative_trapezoid(Cr, Ti)]
        )
        col3 = torch.cat(
            [torch.tensor([0], device=Cr.device), -torch.cumulative_trapezoid(Ct, Ti)]
        )
        BigMat = torch.stack([col1, col2, col3])
        obj_nnls_noa = torch.linalg.lstsq(
            BigMat.T, Ct.unsqueeze(1), rcond=None
        )  # replace with non-negative

        count = 0
        res_vec = torch.tensor([], device=Cr.device)
        tD_all = torch.arange(tD_a, tD_b + 0.25, 0.25)
        tP_all = torch.arange(tD_a + 1, tP_b + 0.25, 0.25)
        alpha_all = torch.arange(alpha_a, alpha_b + 0.25, 0.25)
        x,y,z = torch.meshgrid([tD_all,tP_all,alpha_all])
        all_comb = torch.stack([x.flatten(),y.flatten(),z.flatten()])
        ind = all_comb[1] >= all_comb[0]+1 #As tP ~ U(tD+1,tP_b), then only  retain tP < tD+1
        filtered_comb = all_comb.transpose(1,0)[ind] 
        tD = filtered_comb[:,0].view(-1,1)
        tP = filtered_comb[:,1].view(-1,1)
        alpha = filtered_comb[:,2].view(-1,1)

        ht = compute_ht(Ti,tD,tP,alpha)
        sample_num = ht.shape[0]
        col4 = torch.cat([torch.zeros(sample_num,1),-torch.cumulative_trapezoid(Ct * ht, Ti)],dim=1)
        BigMat = torch.stack([col1.repeat(sample_num,1), col2.repeat(sample_num,1), col3.repeat(sample_num,1), col4],dim = 2)
        obj_nnls_MA = torch.linalg.lstsq(BigMat, Ct.repeat(BigMat.shape[0],1).unsqueeze(2), rcond=False) #solution size : [num_of_sample,4,1]
        nnls_mat = torch.cat([obj_nnls_MA.solution.squeeze(),tD,tP,alpha ],dim = 1)
        residuals = (Ct.repeat(sample_num,1).unsqueeze(2) - BigMat@ obj_nnls_MA.solution).sum(dim=[1,2])
        obj_nnls_a = nnls_mat[residuals == torch.min(residuals)]

        # for return
        obj_nnls_noa_result = obj_nnls_noa.solution.squeeze()
        obj_nnls_a_result = obj_nnls_a.squeeze()
    else:
        obj_nnls_noa_result = []
        obj_nnls_a_result = []

    nT = Ti.shape[0]
    # Sobs = smooth_spline(torch.linspace(1,nT,nT,device=Ct.device),Ct)
    Sobs = Ct
    errorM1 = torch.tensor([], device=Cr.device)
    errorM2 = torch.tensor([], device=Cr.device)
    param_noact = torch.tensor([], device=Cr.device)
    param_act = torch.tensor([], device=Cr.device)
    # Observed summary statistics
    sample_n = 10000 #10^6
    ITER = S // sample_n
    for iter in range(ITER):
        #sample from prior
        R1 = torch.empty(sample_n, 1).uniform_(R1a, R1b).to(Ct.device)
        K2 = torch.empty(sample_n, 1).uniform_(K2alpha, K2beta).to(Ct.device)
        K2a = torch.empty(sample_n, 1).uniform_(K2a_alpha, K2a_beta).to(Ct.device)
        gamma = torch.empty(sample_n, 1).uniform_(gamma_a, gamma_b).to(Ct.device)
        tD = torch.empty(sample_n, 1).uniform_(tD_a, tD_b).to(Ct.device)
        tP = (
            (tD + 1 - tP_b) * torch.rand(sample_n, 1, device=Ct.device).to(Ct.device)
            + tP_b
        ).to(Ct.device)
        alpha = torch.empty(sample_n, 1).uniform_(tD_a, tD_b).to(Ct.device)

        #simulate data 
        Ssim1, Ssim2 = Gen_Curve(
            Ct,
            Cr=Cr,
            Ti=Ti,
            R1=R1,
            K2=K2,
            K2a=K2a,
            gamma=gamma,
            tD=tD,
            tP=tP,
            alpha=alpha,
        )

        # S_no_act = smooth_spline(torch.linspace(1,nT,nT,device=Ct.device),Ssim1) 
        S_no_act = Ssim1
        # S_act = smooth_spline(torch.linspace(1,nT,nT).to(Ct.device),Ssim2)
        errorM1_ = (Sobs - S_no_act).abs().sum(dim=1)
        errorM2_ = (Sobs - Ssim2).abs().sum(dim=1)
        errorM1 = torch.cat((errorM1, errorM1_))
        errorM2 = torch.cat((errorM2, errorM2_))
        param_noact = torch.cat((param_noact, torch.cat((R1, K2, K2a), dim=1)))
        param_act = torch.cat(
            (param_act, torch.cat((R1, K2, K2a, gamma, tD, tP, alpha), dim=1))
        )

    h1 = torch.quantile(errorM1, q=h)
    out1 = param_noact[errorM1 < h1]
    h2 = torch.quantile(errorM2, q=h)
    out2 = param_act[errorM2 < h2]
    Error2_rep = errorM2[errorM2 < h2].mean().item()

    est_K2a = out2[:, 2].view(-1, 1)
    est_gamma = out2[:, 3].view(-1, 1)
    est_tD = out2[:, 4].view(-1, 1)
    est_tP = out2[:, 5].view(-1, 1)
    est_alpha = out2[:, 6].view(-1, 1)
    ht = compute_ht(Ti,est_tD,est_tP,est_alpha)
    k2at_acc = k2a_per + est_gamma * ht * k2a_per / est_K2a

    est_K2a = param_act[:, 2].view(-1, 1)
    est_gamma = param_act[:, 3].view(-1, 1)
    est_tD = param_act[:, 4].view(-1, 1)
    est_tP = param_act[:, 5].view(-1, 1)
    est_alpha = param_act[:, 6].view(-1, 1)
    ht = compute_ht(Ti,est_tD,est_tP,est_alpha)
    k2at_all = k2a_per + est_gamma * ht * k2a_per / est_K2a

    if PLOT == True:
        out1 = out1.to("cpu")
        out2 = out2.to("cpu")
        f, ax = plt.subplots(1, 3, figsize=(15, 5))
        sns.kdeplot(out1[:, 0], ax=ax[0])
        ax[0].axvline(x=out1[:, 0].mean(), linestyle="--")
        ax[0].set_xlabel("$R_{1}$")

        sns.kdeplot(out1[:, 1], ax=ax[1])
        ax[1].axvline(x=out1[:, 1].mean(), linestyle="--")
        ax[1].set_xlabel("$k_{3}$")

        sns.kdeplot(out1[:, 2], ax=ax[2])
        ax[2].axvline(x=out1[:, 2].mean(), linestyle="--")
        ax[2].set_xlabel("$k_{2a}$")
        plt.savefig("figure/posterior_noactivation.png", dpi=200, bbox_inches="tight")

        f, ax = plt.subplots(2, 2, figsize=(10, 10))
        sns.kdeplot(out2[:, 0], ax=ax[0, 0])
        ax[0, 0].axvline(x=out2[:, 0].mean(), linestyle="--")
        ax[0, 0].set_xlabel("$R_{1}$")

        sns.kdeplot(out2[:, 1], ax=ax[0, 1])
        ax[0, 1].axvline(x=out2[:, 1].mean(), linestyle="--")
        ax[0, 1].set_xlabel("$k_{2}$")

        sns.kdeplot(out2[:, 2], ax=ax[1, 0])
        ax[1, 0].axvline(x=out2[:, 2].mean(), linestyle="--")
        ax[1, 0].set_xlabel("$k_{2a}$")

        sns.kdeplot(out2[:, 3], ax=ax[1, 1])
        ax[1, 1].axvline(x=out2[:, 3].mean(), linestyle="--")
        ax[1, 1].set_xlabel("$\gamma$")
        plt.savefig(
            "figure/posterior_activation_explict.png", dpi=200, bbox_inches="tight"
        )

        f, ax = plt.subplots(2, 2, figsize=(10, 10))
        sns.histplot(out2[:, 0], ax=ax[0, 0], stat="density")
        sns.kdeplot(out2[:, 0], ax=ax[0, 0])
        ax[0, 0].axvline(x=out2[:, 0].mean(), linestyle="--")
        ax[0, 0].set_xlabel("$R_{1}$")

        sns.histplot(out2[:, 1], ax=ax[0, 1], stat="density")
        sns.kdeplot(out2[:, 1], ax=ax[0, 1])
        ax[0, 1].axvline(x=out2[:, 1].mean(), linestyle="--")
        ax[0, 1].set_xlabel("$k_{2}$")

        sns.histplot(out2[:, 2], ax=ax[1, 0], stat="density")
        sns.kdeplot(out2[:, 2], ax=ax[1, 0])
        ax[1, 0].axvline(x=out2[:, 2].mean(), linestyle="--")
        ax[1, 0].set_xlabel("$k_{2a}$")

        sns.histplot(out2[:, 3], ax=ax[1, 1], stat="density")
        sns.kdeplot(out2[:, 3], ax=ax[1, 1])
        ax[1, 1].axvline(x=out2[:, 3].mean(), linestyle="--")
        ax[1, 1].set_xlabel("$\gamma$")
        plt.savefig(
            f"figure/posterior_activation_explict_hist_{Seq}.png",
            dpi=200,
            bbox_inches="tight",
        )

        f, ax = plt.subplots(1, 3, figsize=(15, 5))
        sns.kdeplot(out2[:, 4], ax=ax[0])
        ax[0].axvline(x=out2[:, 4].mean(), linestyle="--")
        ax[0].set_xlabel("$t_D$")

        sns.kdeplot(out2[:, 5], ax=ax[1])
        ax[1].axvline(x=out2[:, 5].mean(), linestyle="--")
        ax[1].set_xlabel("$t_P$")

        sns.kdeplot(out2[:, 6], ax=ax[2])
        ax[2].axvline(x=out2[:, 6].mean(), linestyle="--")
        ax[2].set_xlabel("$alpha$")
        plt.savefig(
            "figure/posterior_activation_implict.png", dpi=200, bbox_inches="tight"
        )
        k2at_acc = k2at_acc.to("cpu")
        f, ax = plt.subplots(1, 1, figsize=(5, 5))
        k2at_acc_low_quantile = torch.quantile(k2at_acc, dim=0, q=k2a_int[0])
        k2at_acc_high_quantile = torch.quantile(k2at_acc, dim=0, q=k2a_int[1])
        k2at_acc_mean = k2at_acc.mean(dim=0)
        Ti = Ti.cpu()
        ax.plot(Ti, k2at_acc_mean)
        ax.fill_between(Ti, k2at_acc_low_quantile, k2at_acc_high_quantile, alpha=0.2)
        ax.set_xlabel("Time (mins)")
        ax.set_ylabel("$k_{2a}(t),(\% baseline)$")
        plt.savefig("figure/k2at.png", dpi=200, bbox_inches="tight")
        plt.close()
    if Sequential:
        return {
            "ABCout_act": param_act,
            "ABCout_act_accepted": out2,
            "error_act": errorM2,
            "tol_act": h2,
            "ABCout_noact": param_noact,
            "ABCout_noact_accepted": out1,
            "error_noact": errorM1,
            "tol_noact": h1,
            "k2at_all": k2at_all,
            "k2at_acc": k2at_acc,
            "obj_nnls_noa": obj_nnls_noa_result,
            "nnls_a": obj_nnls_a_result,
        }, Error2_rep
    else:
        return {
            "ABCout_act": param_act,
            "ABCout_act_accepted": out2,
            "error_act": errorM2,
            "tol_act": h2,
            "ABCout_noact": param_noact,
            "ABCout_noact_accepted": out1,
            "error_noact": errorM1,
            "tol_noact": h1,
            "k2at_all": k2at_all,
            "k2at_acc": k2at_acc,
            "obj_nnls_noa": obj_nnls_noa_result,
            "nnls_a": obj_nnls_a_result,
        }











'''
slow version nnls, nest for loop
for tD in torch.arange(tD_a, tD_b + 0.25, 0.25):
    for tP in torch.arange(tD + 1, tP_b + 0.25, 0.25):
        for alpha in torch.arange(alpha_a, alpha_b + 0.25, 0.25):
            count += 1
            ht = compute_ht(Ti,tD,tP,alpha)
            col4 = torch.cat(
                [
                    torch.tensor([0], device=Cr.device),
                    -torch.cumulative_trapezoid(Ct * ht, Ti),
                ]
            )
            BigMat = torch.stack([col1, col2, col3, col4])
            obj_nnls_MA = torch.linalg.lstsq(
                BigMat.T, Ct.unsqueeze(1), rcond=False
            )
            if count == 1:
                nnls_mat = torch.cat(
                    (
                        obj_nnls_MA.solution.squeeze(),
                        tD.unsqueeze(0),
                        tP.unsqueeze(0),
                        alpha.unsqueeze(0),
                    )
                ).unsqueeze(1)
            else:
                nnls_mat_ = torch.cat(
                    (
                        obj_nnls_MA.solution.squeeze(),
                        tD.unsqueeze(0),
                        tP.unsqueeze(0),
                        alpha.unsqueeze(0),
                    )
                ).unsqueeze(1)
                nnls_mat = torch.cat((nnls_mat, nnls_mat_), dim=1)
            residuals = (
                Ct.unsqueeze(1) - BigMat.T @ obj_nnls_MA.solution
            ).sum()
            if not torch.isnan(residuals).item():
                res_vec = torch.cat((res_vec, residuals.unsqueeze(0)))
obj_nnls_a = nnls_mat[:, res_vec == torch.min(res_vec)]


'''